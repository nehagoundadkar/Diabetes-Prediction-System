import pandas as pd
from django.shortcuts import render,HttpResponse
import numpy as np
import matplotlib.pyplot as plt
import array as arr
#initialisation of dataframe and centroid for clustering

df = pd.read_csv('c:/Users/Admin/Downloads/Edge Downloads/database_DMW/diabetes.csv',header=0)
x=df['Glucose']
y=df['Age']
np.random.seed(200) #for random same number each time 
k = 4 #k value
centroids = {
    i+1: [np.random.randint(0, 200), np.random.randint(10,80)]
    for i in range(k)
}
fig = plt.figure(figsize=(6, 6))
plt.scatter(x, y, color='k')
colmap = {1: 'b', 2: 'r',3: 'c', 4: 'y'} #mapping blue color with 1 and red color with 2 for centroid
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.xlim(0, 200)
plt.ylim(0, 100)
plt.xlabel('Glucose')
plt.ylabel('Age')
#plt.show()
#Assignment stage- Here we are will assign each point to any cluster


def assignment(df, centroids):
    for i in centroids.keys():
        #Euclidian Distance Formula
        # sqrt((x1 - x2)^2 - (y1 - y2)^2) 

        df['distance_from_{}'.format(i)] = (
            np.sqrt(
                (x - centroids[i][0]) ** 2
                + (y - centroids[i][1]) ** 2
            )
        )
    centroid_distance_cols = ['distance_from_{}'.format(i) for i in centroids.keys()]
    df['closest'] = df.loc[:, centroid_distance_cols].idxmin(axis=1)
    df['closest'] = df['closest'].map(lambda x: int(x.lstrip('distance_from_')))
    df['color'] = df['closest'].map(lambda x: colmap[x])
    return df

df = assignment(df, centroids)
print(df) #printing all elements distance from centroid 1 and 2 and their closest centroid and their color

fig = plt.figure(figsize=(5, 5))
plt.scatter(x, y, color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.xlim(0, 200)
plt.ylim(0, 100)
plt.xlabel('Glucose')
plt.ylabel('Age')
#plt.show()

#update stage



import copy

old_centroids = copy.deepcopy(centroids)
#updating centroid after calculating of closest centroid
def update(k):
    for i in centroids.keys():
        centroids[i][0] = np.mean(x[df['closest'] == i])
        centroids[i][1] = np.mean(y[df['closest'] == i])
    return k

centroids = update(centroids)
    
fig = plt.figure(figsize=(5, 5))
ax = plt.axes()
plt.scatter(x, y, color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.xlim(0, 200)
plt.ylim(0, 100)
plt.xlabel('Glucose')
plt.ylabel('Age')
#plt.show()



## Repeat Assigment Stage
df = assignment(df, centroids)

# Plot results
fig = plt.figure(figsize=(5, 5))
plt.scatter(x,y, color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.xlim(0, 200)
plt.ylim(0, 100)
plt.xlabel('Glucose')
plt.ylabel('Age')
#plt.show()
#  until all assigned categories don't change any more
while True:
    closest_centroids = df['closest'].copy(deep=True)
    centroids = update(centroids)
    df = assignment(df, centroids)
    if closest_centroids.equals(df['closest']):
        break

fig = plt.figure(figsize=(5, 5))
plt.scatter(x, y, color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.xlim(0, 200)
plt.ylim(0, 100)
plt.xlabel('Glucose')
plt.ylabel('Age')
fig.savefig('C:/Users/Admin/Documents/DjangoProject/dmw/static/m1.jpg')

#plt.show()


def kk(request):
    return render(request,'kmeans.html')