from django.apps import AppConfig


class MiningConfig(AppConfig):
    name = 'mining'
