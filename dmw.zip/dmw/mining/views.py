from django.shortcuts import render,HttpResponse
import numpy as np
import pandas as pd
import math
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix, precision_score, classification_report

df = pd.read_csv('c:/Users/Admin/Downloads/Edge Downloads/database_DMW/diabetes.csv')
print(df,'\n\n')

X = df[['Glucose','BloodPressure','SkinThickness','Insulin','BMI','DiabetesPedigreeFunction','Age']]
Y = df['Outcome']
#X = df.iloc[:,0:8].values
#print(X)
#Y = df.iloc[:,-1].values
#print(Y)
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.25, random_state = 0)

#get user input
def index(request):
    return render(request,'index.html')

#print("Amit111")

def predict(request):
   # print("ABDDDDDDDDDDDDDD")
   # print("Amit111")
    if request.method=="POST":
        print("Amit111")
        glucose=request.POST['glucose']
        BloodPressure=request.POST['bp']
        SkinThickness=request.POST['skin']
        Insulin=request.POST['insulin']
        BMI=request.POST['bmi']
        DPF=request.POST['dpf']
        age=request.POST['age']

        user_data = {
                'glucose': glucose,
                'BloodPressure': BloodPressure,
                'SkinThickness': SkinThickness,
                'Insulin': Insulin,
                'BMI': BMI,
                'DPF': DPF,
                'age': age
                }


        user_input = pd.DataFrame(user_data,index=[0] )
        

        print("Hello1111-------")

        m = KNeighborsClassifier(n_neighbors=3)
        m.fit(X_train,Y_train)

        Y_pred = m.predict(X_test)
        print(Y_pred,'\n\n')

        print(Y_test,'\n\n')

        #Accuracy Score
        acurate=math.ceil(accuracy_score(Y_test, Y_pred)*100)
        print(acurate)

        #User Prediction
        user_prediction = m.predict(user_input)
        if user_prediction == 0:
            print("No diabetes detection")
            up="Diabetes Not Detected"
        else:
            print("Diabetes detection")
            up="Diabetes Detected"
        print(user_prediction)

        #confusion matrix
        print(confusion_matrix(Y_test, Y_pred))

        #classification report
        print(classification_report(Y_test,Y_pred))
 
        content= {
            't1'    : acurate,
            'p1'    : up
        }

        return render(request,"predict2.html",{'key1':content})





# Create your views here.

